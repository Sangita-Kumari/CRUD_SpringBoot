package com.example.productmanagcrudapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagCrudAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductManagCrudAppApplication.class, args);
    }

}
