package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @GetMapping("/")
    public String home(){
        return "add";

    }

//    @GetMapping("/load_form")
    @GetMapping("/load_form")
    public String loadForm(){
        return "index";
    }
    @GetMapping("/edit_form")
    public String editForm(){
        return "index";
    }
}
